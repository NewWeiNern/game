using System;

[Serializable]
public class FoodItem{
    public string name;
    public string[] type;
}