using System;

[Serializable]
class FoodItems{
    public FoodItem[] items = {};
}